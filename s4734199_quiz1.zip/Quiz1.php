<?php

namespace App\Controllers;

/**
 *	Quiz 1, INFS3202/7202, Sem 1, 2023
 *	Student ID: <You 8-digit Student ID>
 *	Prac Session: <e.g. Prac 1 (In Person), Prac 3 (External), etc.>
 */
class Quiz1 extends BaseController
{   
    protected $helpers = ['form','date'];

    public function index()
    {      
        //echo "Quiz 1 starts here!";
        echo view('input');
        
        //echo date_default_timezone_set('America/New_York');
        echo date_default_timezone_get(). '=>' . date('e') . '=>' . date('T');
       
    }
    public function Quiz1Controller()
    {
        // Task 3 & 4 - WRITE YOUR CODE HERE
        $rules = [];

        if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
            echo view("input");
        }
        else {
            $username = $this->request->getPost('username');
            $message = $this->request->getPost('message');

            if($username && $message){
                if (strlen($username)>=4 && strlen($username)<=20 && ($username == '[A-Za-z0-9]')){
                    echo '<script> alert ("valid username") </script>';
                        setcookie('var1', $username, time() + (86400 * 30), "/");
                        
                } 
                else {
                    echo '<script>alert("Enter valid username")</script>';
                }
    
                if(strlen($message)<=10 && strlen($message)>=1000){
                        echo '<script> alert ("Valid message) </script>';
                        setcookie('var2', $message, time() + (86400 * 30), "/");
                }
                else{
                    echo '<script>alert("Enter valid message")</script>';
                }
            }
            
            if ($username && $message){
                echo view ('output.php');
            }
            else{
                echo view('input.php');
            }

        }

        // Task 3 & 4 - END
    }
}

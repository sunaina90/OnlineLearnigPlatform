<html>
<head>
    <title>Data Input</title>
</head>
<body>
    <?= validation_list_errors() ?>
    <!-- Task 1 - WRITE YOUR CODE HERE -->
        <?= form_open_multipart(base_url().'upload/upload_file') ?>
        <label for ="username"> Username </label>
        <br>
        <input type = "text" name ="username" size ="20">
        <br><br>
        <label for ="message"> Message </label>
        <br>
        <input type = "text" name ="message" size ="20">
        <input type="submit" value="submit">

        <br><br>

    <!-- Task 1 - END -->
</body>
</html>
